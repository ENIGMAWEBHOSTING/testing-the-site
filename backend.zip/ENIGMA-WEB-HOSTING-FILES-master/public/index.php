<?php

require_once '../app/init.php';

$App = new App;