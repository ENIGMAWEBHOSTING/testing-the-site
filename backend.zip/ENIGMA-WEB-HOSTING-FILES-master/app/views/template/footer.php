<?php 
    require_once '../app/views/user/jsHandler/' . $data['title'] . 'Js.php';
?>
</body>

</html>