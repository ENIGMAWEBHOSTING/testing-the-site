 
<img class="bg" src="bg.jpg" alt="background">
<div class="container">
    <h1>Login</h3>
    <!-- <p>Enter your details</p> -->
    <!-- <?php
    if($insert  == true){
    echo '<p class="submitMsg">Thank you for registering for our free services</p>';
    }
?> -->
    <form action="index.php" method="post">
        <input type="text" name="mail" id="email" placeholder="Enter your email">
        <input type="text" name="password" id="pass" placeholder="Enter your password">
        <button class="btn">Submit</button> 
    </form>

    <login>   
       Dont have an account? <a href="registration.html">Register</a>
    </login>
    <br>
   

</div>

