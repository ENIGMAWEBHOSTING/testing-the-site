
    <img class="bg" src="bg.jpg" alt="background">
    <div class="container">
        <h1>Registration</h3>
        <p>Enter your details</p>
        <!-- <?php
        if($insert == true){
        echo '<p class="submitMsg">Thank you for registering for our free services</p>';
        }
    ?> -->
        <form action="index.php" method="post">
            <input type="text" name="username" id="name" placeholder="Enter your username">
            <input type="text" name="firstname" id="name" placeholder="Enter your first name">
            <input type="text" name="lastname" id="name" placeholder="Enter your last name">
            <input type="email" name="email" id="email" placeholder="Enter your email">
            <input type="phone" name="password" id="pass" placeholder="Enter your password">
            <button class="btn">Submit</button> 
        </form>

        <login>
           Already have an account? <a href="login.html">login</a>
        </login>
        <br>
