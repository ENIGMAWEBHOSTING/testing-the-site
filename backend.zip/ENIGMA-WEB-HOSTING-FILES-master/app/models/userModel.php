<?php

class userModel{
    private $dbName = 'enigma';
    private $dbUser = 'root';
    private $dbPass = '';
    private $db;
    private $query;

    public function __construct()
    {
        $db = 'mysql:host=localhost;dbname=' . $this->dbName;

        try {
            $this->db = new PDO($db, $this->dbUser, $this->dbPass);
        } catch (PDOEception $e) {
            die($e->getMessage());
        }
    }

}