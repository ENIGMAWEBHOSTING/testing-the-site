<?php

define('__BASEURL', 'http://localhost/enigma/public');