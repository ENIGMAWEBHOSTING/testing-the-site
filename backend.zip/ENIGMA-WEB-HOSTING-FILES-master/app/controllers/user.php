<?php

class User extends Controller{
    protected $method = 'index';

    public function index()
    {
        $User = new User;    
        $Data['title'] = 'homepage';
        $User->view('template/header',$Data);
        $User->view('user/homepage');
        $User->view('template/footer',$Data);
        
    }

    public function login()
    {
        $User = new User;
        $Data['title'] = 'login';
        $Data['user'] = $User->model('userModel');
        $User->view('template/header',$Data);
        $User->view('user/login');
        $User->view('template/footer',$Data);
        
    }

    public function register()
    {
        $User = new User;
        $Data['title'] = 'register';
        $User->view('template/header',$Data);
        $User->view('user/register');
        $User->view('template/footer',$Data);
        
    }

}